import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import { ShoppingBag, UserRound, Menu, X, Search, Plus, Minus, Trash2, LogOut, Package, LayoutDashboard, MapPin, Instagram, MessageCircle, ArrowRight, CheckCircle2 } from 'lucide-react';
import './styles.css';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = SUPABASE_URL && SUPABASE_KEY && !SUPABASE_URL.includes('YOUR_PROJECT_ID')
  ? createClient(SUPABASE_URL, SUPABASE_KEY)
  : null;

const store = { phone: '918699755786', displayPhone: '+91 86997 55786', address: 'Kamal Vihar, Jalandhar City, Punjab, India', instagram: 'Aditya.pal2311' };
const starterProducts = [
  { id:'sample-1', name:'Rose Garden Suit Set', category:'Suit Sets', price:2499, stock:8, image_url:'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=85', description:'A graceful festive look with elegant details.' },
  { id:'sample-2', name:'Classic Festive Ensemble', category:'Festive', price:3299, stock:5, image_url:'https://images.unsplash.com/photo-1583391733956-6c78276477e4?auto=format&fit=crop&w=800&q=85', description:'A special-occasion style for memorable days.' },
  { id:'sample-3', name:'Everyday Ethnic Elegance', category:'Ethnic Wear', price:1599, stock:10, image_url:'https://images.unsplash.com/photo-1597983073493-88cd35cf93e0?auto=format&fit=crop&w=800&q=85', description:'Comfortable style for your everyday wardrobe.' },
  { id:'sample-4', name:'Golden Detail Accessories', category:'Accessories', price:799, stock:12, image_url:'https://images.unsplash.com/photo-1617038220319-276d3cfab638?auto=format&fit=crop&w=800&q=85', description:'A finishing touch to complete your look.' },
  { id:'sample-5', name:'Heritage Print Suit', category:'Suit Sets', price:2199, stock:6, image_url:'https://images.unsplash.com/photo-1603217192097-13c306522271?auto=format&fit=crop&w=800&q=85', description:'A boutique pick inspired by timeless tradition.' },
  { id:'sample-6', name:'Celebration Edit', category:'Festive', price:2899, stock:4, image_url:'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=800&q=85', description:'An elevated look for celebrations and gatherings.' },
  { id:'sample-7', name:'Graceful Daily Wear', category:'Ethnic Wear', price:1399, stock:9, image_url:'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=800&q=85', description:'Effortless style with a classic feel.' },
  { id:'sample-8', name:'Classic Jewellery Accent', category:'Accessories', price:599, stock:15, image_url:'https://images.unsplash.com/photo-1611652022419-a9419f74343d?auto=format&fit=crop&w=800&q=85', description:'A little sparkle for your favourite outfit.' }
];
const money = n => new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(Number(n)||0);
const wa = text => `https://wa.me/${store.phone}?text=${encodeURIComponent(text)}`;

function App(){
  const [products,setProducts]=useState(starterProducts);
  const [loadingProducts,setLoadingProducts]=useState(false);
  const [session,setSession]=useState(null);
  const [profile,setProfile]=useState(null);
  const [authMode,setAuthMode]=useState('login');
  const [authOpen,setAuthOpen]=useState(false);
  const [cartOpen,setCartOpen]=useState(false);
  const [adminOpen,setAdminOpen]=useState(false);
  const [mobileMenu,setMobileMenu]=useState(false);
  const [cart,setCart]=useState([]);
  const [query,setQuery]=useState('');
  const [category,setCategory]=useState('All');
  const [notice,setNotice]=useState('');
  const [busy,setBusy]=useState(false);
  const [orders,setOrders]=useState([]);
  const [adminTab,setAdminTab]=useState('orders');
  const [productForm,setProductForm]=useState({name:'',category:'Ethnic Wear',price:'',stock:'0',image_url:'',description:''});
  const [checkout,setCheckout]=useState({name:'',phone:'',address:'',notes:''});
  const [myOrders,setMyOrders]=useState([]);
  const [orderPlaced,setOrderPlaced]=useState(null);

  useEffect(()=>{
    if(!supabase) return;
    supabase.auth.getSession().then(({data})=>setSession(data.session));
    const {data:{subscription}}=supabase.auth.onAuthStateChange((_event,s)=>{setSession(s);setProfile(null)});
    return ()=>subscription.unsubscribe();
  },[]);
  useEffect(()=>{ if(session) loadProfile(); else {setProfile(null);setMyOrders([])} },[session]);
  useEffect(()=>{ loadProducts(); },[session,profile?.role]);
  async function loadProfile(){
    if(!supabase||!session?.user)return;
    const {data}=await supabase.from('profiles').select('id,full_name,role').eq('id',session.user.id).maybeSingle();
    setProfile(data||{id:session.user.id,full_name:session.user.user_metadata?.full_name||'',role:'customer'});
    const {data:mine}=await supabase.from('orders').select('*').eq('customer_id',session.user.id).order('created_at',{ascending:false}).limit(20);
    setMyOrders(mine||[]);
  }
  async function loadProducts(){
    if(!supabase)return;
    setLoadingProducts(true);
    let req=supabase.from('products').select('*').order('created_at',{ascending:false});
    if(profile?.role!=='admin')req=req.eq('active',true);
    const {data,error}=await req;
    if(!error&&data&&data.length)setProducts(data);
    else if(!error&&data&&data.length===0)setProducts([]);
    setLoadingProducts(false);
  }
  const filtered=useMemo(()=>products.filter(p=>(category==='All'||p.category===category)&&(`${p.name} ${p.category} ${p.description||''}`).toLowerCase().includes(query.toLowerCase())),[products,category,query]);
  const cartCount=cart.reduce((s,x)=>s+x.qty,0),total=cart.reduce((s,x)=>s+Number(x.price)*x.qty,0);
  function add(p){setCart(prev=>{const found=prev.find(x=>x.id===p.id);return found?prev.map(x=>x.id===p.id?{...x,qty:Math.min(x.qty+1,Number(p.stock||99))}:x):[...prev,{...p,qty:1}]});setNotice(`${p.name} added to bag`);setTimeout(()=>setNotice(''),2500)}
  function quantity(id,delta){setCart(prev=>prev.map(x=>x.id===id?{...x,qty:x.qty+delta}:x).filter(x=>x.qty>0))}
  async function signIn(e){e.preventDefault();if(!supabase){setNotice('Setup required: add your Supabase project URL and publishable key.');return}setBusy(true);const f=new FormData(e.currentTarget);const result=authMode==='signup'?await supabase.auth.signUp({email:f.get('email'),password:f.get('password'),options:{data:{full_name:f.get('name')}}}):await supabase.auth.signInWithPassword({email:f.get('email'),password:f.get('password')});setBusy(false);if(result.error)setNotice(result.error.message);else{setAuthOpen(false);setNotice(authMode==='signup'?'Account created. Check email if confirmation is enabled.':'Welcome back!')}}
  async function signOut(){await supabase?.auth.signOut();setAdminOpen(false);setNotice('You have signed out.')}
  async function placeOrder(e){
    e.preventDefault();
    if(!session){setNotice('Please sign in or create an account before placing an order.');setAuthMode('login');setAuthOpen(true);return}
    if(!cart.length)return;
    setBusy(true);
    const payload={customer_id:session.user.id,customer_name:checkout.name,phone:checkout.phone,address:checkout.address,notes:checkout.notes,items:cart.map(x=>({product_id:x.id,name:x.name,price:Number(x.price),quantity:x.qty})),total,status:'pending',payment_status:'pay_on_confirmation'};
    if(!supabase){setBusy(false);return}
    const {data,error}=await supabase.from('orders').insert(payload).select().single();
    setBusy(false);
    if(error){setNotice(`Order could not be saved: ${error.message}`);return}
    setOrderPlaced(data);setCart([]);setCartOpen(false);setCheckout({name:'',phone:'',address:'',notes:''});await loadProfile();
  }
  async function loadAdminOrders(){if(!supabase||profile?.role!=='admin')return;const {data,error}=await supabase.from('orders').select('*').order('created_at',{ascending:false}).limit(200);if(!error)setOrders(data||[]);else setNotice(error.message)}
  useEffect(()=>{if(adminOpen&&profile?.role==='admin')loadAdminOrders()},[adminOpen,adminTab,profile?.role]);
  async function saveProduct(e){
    e.preventDefault();if(!supabase||profile?.role!=='admin')return;
    setBusy(true);const payload={...productForm,price:Number(productForm.price),stock:Number(productForm.stock),active:true};
    const {error}=await supabase.from('products').insert(payload);setBusy(false);
    if(error){setNotice(error.message);return}setProductForm({name:'',category:'Ethnic Wear',price:'',stock:'0',image_url:'',description:''});await loadProducts();setNotice('Product saved.');
  }
  async function deleteProduct(id){if(!confirm('Delete this product?'))return;const {error}=await supabase.from('products').delete().eq('id',id);if(error)setNotice(error.message);else loadProducts()}
  async function updateOrder(id,status){const {error}=await supabase.from('orders').update({status}).eq('id',id);if(error)setNotice(error.message);else loadAdminOrders()}
  const monthly=orders.reduce((acc,o)=>{const key=new Date(o.created_at).toLocaleDateString('en-IN',{month:'short',year:'numeric'});acc[key]=(acc[key]||0)+Number(o.total);return acc}, {});
  return <><div className="announcement">A LITTLE LUXURY, WOVEN WITH LOVE · JALANDHAR, PUNJAB</div>
    <header className="nav"><a className="brand" href="#home">SHRI RAM BOUTIQUE<span>TRADITION · STYLE · GRACE</span></a><button className="mobileToggle" onClick={()=>setMobileMenu(!mobileMenu)} aria-label="Toggle menu">{mobileMenu?<X/>:<Menu/>}</button><nav className={mobileMenu?'links show':'links'}><a href="#home" onClick={()=>setMobileMenu(false)}>Home</a><a href="#collections" onClick={()=>setMobileMenu(false)}>Collections</a><a href="#shop" onClick={()=>setMobileMenu(false)}>Shop</a><a href="#story" onClick={()=>setMobileMenu(false)}>Our Story</a><a href="#contact" onClick={()=>setMobileMenu(false)}>Contact</a></nav><div className="navActions"><button className="iconButton" onClick={()=>{setAuthMode('login');setAuthOpen(true)}} title="Account"><UserRound size={18}/></button>{session&&profile?.role==='admin'&&<button className="iconButton" onClick={()=>setAdminOpen(true)} title="Admin"><LayoutDashboard size={18}/></button>}<button className="button small" onClick={()=>setCartOpen(true)}><ShoppingBag size={15}/> Bag ({cartCount})</button></div></header>
    <main id="home"><section className="hero"><div className="heroText"><span className="eyebrow">THE NEW ETHNIC EDIT</span><h1>Tradition, with a touch of timeless.</h1><p>Thoughtfully chosen styles for celebrations, everyday elegance and the moments that matter.</p><a className="button" href="#shop">EXPLORE THE COLLECTION <ArrowRight size={16}/></a><div className="heroNote"><span>✦</span> Curated style. Personal service.</div></div><div className="heroPhoto" aria-label="Indian ethnic fashion" role="img"></div></section>
    <section className="section" id="collections"><div className="sectionHead"><span className="eyebrow">SHOP BY STYLE</span><h2>Collections for every occasion</h2><p>Classic craftsmanship. Beautiful details. Your kind of style.</p></div><div className="categoryGrid">{[['Ethnic Wear','photo-1610030469983-98e550d6193c'],['Festive','photo-1583391733956-6c78276477e4'],['Suit Sets','photo-1597983073493-88cd35cf93e0'],['Accessories','photo-1617038220319-276d3cfab638']].map(([name,img])=><button className="categoryTile" key={name} onClick={()=>{setCategory(name);document.querySelector('#shop').scrollIntoView({behavior:'smooth'})}}><img src={`https://images.unsplash.com/${img}?auto=format&fit=crop&w=600&q=80`} alt={name}/><span>{name}</span></button>)}</div></section>
    <section className="section productsSection" id="shop"><div className="sectionHead"><span className="eyebrow">THE BOUTIQUE EDIT</span><h2>Discover your next favourite</h2><p>{supabase?'Shop the current catalogue.':'Catalogue preview shown. Connect Supabase to activate live products and orders.'}</p></div><div className="filters"><label className="search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search the collection…"/></label><select value={category} onChange={e=>setCategory(e.target.value)}><option>All</option><option>Ethnic Wear</option><option>Festive</option><option>Suit Sets</option><option>Accessories</option></select></div>{loadingProducts&&<p className="muted">Updating catalogue…</p>}<div className="productGrid">{filtered.map(p=><article className="product" key={p.id}><div className="productImage"><img src={p.image_url||starterProducts[0].image_url} alt={p.name} loading="lazy"/>{Number(p.stock)===0&&<span className="sold">Out of stock</span>}</div><div className="productInfo"><span className="productCategory">{p.category}</span><h3>{p.name}</h3><p className="description">{p.description}</p><div className="productBottom"><strong>{money(p.price)}</strong><button className="addButton" disabled={Number(p.stock)===0} onClick={()=>add(p)}><Plus size={15}/> Add</button></div></div></article>)}</div>{!filtered.length&&<p className="empty">No products found. Try another search.</p>}</section>
    <section className="callout"><div><span className="eyebrow">PERSONAL SERVICE, ALWAYS</span><h2>Need help choosing your look?</h2><p>Message us for product details, availability and ordering assistance.</p></div><a className="button goldButton" href={wa('Hello Shri Ram Boutique, I would like to enquire about your collection.')} target="_blank" rel="noreferrer"><MessageCircle size={16}/> Chat on WhatsApp</a></section>
    <section className="section story" id="story"><img src="https://images.unsplash.com/photo-1603217192097-13c306522271?auto=format&fit=crop&w=1000&q=85" alt="Fashion detail"/><div><span className="eyebrow">OUR STORY</span><h2>Style that feels like you.</h2><p>At Shri Ram Boutique, we celebrate the beauty of Indian style—from everyday essentials to festive favourites. Our goal is to make discovering your next look warm, personal and effortless.</p><p>Visit us in Kamal Vihar, Jalandhar City, Punjab, or message us to ask about the collection.</p><a className="textLink" href="#contact">Visit our boutique <ArrowRight size={15}/></a></div></section>
    <section className="section contactSection" id="contact"><div className="sectionHead"><span className="eyebrow">WE'D LOVE TO HEAR FROM YOU</span><h2>Visit or get in touch</h2></div><div className="contactGrid"><div className="contactCard"><MapPin/><h3>Find the boutique</h3><p>{store.address}</p><a href="https://www.google.com/maps/search/?api=1&query=Kamal+Vihar%2C+Jalandhar+City%2C+Punjab" target="_blank" rel="noreferrer">Open in Maps <ArrowRight size={14}/></a></div><div className="contactCard"><MessageCircle/><h3>Talk to us</h3><p>{store.displayPhone}<br/>Instagram: @{store.instagram}</p><a href={wa('Hello Shri Ram Boutique!')} target="_blank" rel="noreferrer">WhatsApp us <ArrowRight size={14}/></a><a href={`https://instagram.com/${store.instagram}`} target="_blank" rel="noreferrer"><Instagram size={14}/> Follow on Instagram</a></div></div></section></main>
    <footer className="footer"><div><a className="brand footerBrand" href="#home">SHRI RAM BOUTIQUE<span>TRADITION · STYLE · GRACE</span></a><p>Celebrating style, one beautiful detail at a time.</p></div><div><h4>EXPLORE</h4><a href="#shop">Shop collection</a><a href="#story">Our story</a><a href="#contact">Contact us</a></div><div><h4>CONNECT</h4><a href={wa('Hello Shri Ram Boutique!')}>WhatsApp</a><a href={`https://instagram.com/${store.instagram}`}>Instagram</a><span>Kamal Vihar, Jalandhar</span></div></footer><div className="copyright">© {new Date().getFullYear()} Shri Ram Boutique. All rights reserved.</div>
    {notice&&<div className="toast" role="status">{notice}<button onClick={()=>setNotice('')}><X size={15}/></button></div>}
    {authOpen&&<div className="overlay" onMouseDown={e=>{if(e.target===e.currentTarget)setAuthOpen(false)}}><section className="dialog"><div className="dialogHead"><div><span className="eyebrow">YOUR BOUTIQUE ACCOUNT</span><h2>{authMode==='login'?'Welcome back':'Create your account'}</h2></div><button className="iconButton" onClick={()=>setAuthOpen(false)}><X/></button></div>{!supabase&&<div className="setupWarning">Authentication activates after Supabase is configured using the setup guide.</div>}<form onSubmit={signIn}>{authMode==='signup'&&<label>Full name<input name="name" required autoComplete="name" placeholder="Your full name"/></label>}<label>Email address<input name="email" type="email" required autoComplete="email" placeholder="you@example.com"/></label><label>Password<input name="password" type="password" required minLength="8" autoComplete={authMode==='login'?'current-password':'new-password'} placeholder="At least 8 characters"/></label><button className="button full" disabled={busy}>{busy?'Please wait…':authMode==='login'?'SIGN IN':'CREATE ACCOUNT'}</button></form><p className="switchAuth">{authMode==='login'?"New to Shri Ram Boutique?":"Already have an account?"} <button onClick={()=>setAuthMode(authMode==='login'?'signup':'login')}>{authMode==='login'?'Sign up':'Sign in'}</button></p></section></div>}
    {cartOpen&&<div className="overlay" onMouseDown={e=>{if(e.target===e.currentTarget)setCartOpen(false)}}><section className="dialog cartDialog"><div className="dialogHead"><div><span className="eyebrow">YOUR SELECTION</span><h2>Shopping bag ({cartCount})</h2></div><button className="iconButton" onClick={()=>setCartOpen(false)}><X/></button></div>{!cart.length?<div className="emptyCart"><ShoppingBag size={34}/><p>Your bag is waiting for something lovely.</p><button className="textLink" onClick={()=>setCartOpen(false)}>Continue shopping <ArrowRight size={14}/></button></div>:<><div className="cartItems">{cart.map(x=><div className="cartRow" key={x.id}><img src={x.image_url||starterProducts[0].image_url} alt=""/><div className="cartProduct"><b>{x.name}</b><span>{money(x.price)}</span><div className="qty"><button onClick={()=>quantity(x.id,-1)}><Minus size={13}/></button><span>{x.qty}</span><button onClick={()=>quantity(x.id,1)} disabled={x.qty>=Number(x.stock||99)}><Plus size={13}/></button><button className="remove" onClick={()=>setCart(c=>c.filter(i=>i.id!==x.id))}><Trash2 size={14}/></button></div></div><strong>{money(x.price*x.qty)}</strong></div>)}</div><div className="cartTotal"><span>Order total</span><b>{money(total)}</b></div><div className="setupWarning">Online payments are not enabled yet. Your order will be saved as pending and the shop will confirm payment/delivery details with you.</div>{session?<form onSubmit={placeOrder} className="checkoutForm"><h3>Delivery details</h3><label>Full name<input required value={checkout.name} onChange={e=>setCheckout({...checkout,name:e.target.value})}/></label><label>Phone number<input required type="tel" value={checkout.phone} onChange={e=>setCheckout({...checkout,phone:e.target.value})}/></label><label>Delivery address<input required value={checkout.address} onChange={e=>setCheckout({...checkout,address:e.target.value})}/></label><label>Notes (optional)<textarea value={checkout.notes} onChange={e=>setCheckout({...checkout,notes:e.target.value})} rows="2"/></label><button className="button full" disabled={busy}>{busy?'Saving order…':'PLACE ORDER · '+money(total)}</button></form>:<button className="button full" onClick={()=>{setCartOpen(false);setAuthMode('login');setAuthOpen(true)}}>SIGN IN TO PLACE ORDER</button>}</>}</section></div>}
    {orderPlaced&&<div className="overlay"><section className="dialog successDialog"><CheckCircle2 size={42}/><h2>Order request saved</h2><p>Your order reference is <b>{orderPlaced.id.slice(0,8).toUpperCase()}</b>. Shri Ram Boutique will contact you to confirm availability and payment/delivery details.</p><a className="button full" href={wa(`Hello Shri Ram Boutique, I placed order ${orderPlaced.id.slice(0,8).toUpperCase()} for ${money(orderPlaced.total)}. Please confirm my order.`)} target="_blank" rel="noreferrer">CONFIRM ON WHATSAPP</a><button className="textLink" onClick={()=>setOrderPlaced(null)}>Close</button></section></div>}
    {adminOpen&&<div className="overlay"><section className="dialog adminDialog"><div className="dialogHead"><div><span className="eyebrow">STORE MANAGEMENT</span><h2>Admin dashboard</h2></div><button className="iconButton" onClick={()=>setAdminOpen(false)}><X/></button></div>{profile?.role!=='admin'?<p>Admin access required.</p>:<><div className="adminTabs"><button className={adminTab==='orders'?'active':''} onClick={()=>setAdminTab('orders')}><Package size={15}/> Orders & sales</button><button className={adminTab==='products'?'active':''} onClick={()=>setAdminTab('products')}><Plus size={15}/> Products</button></div>{adminTab==='orders'?<><div className="salesGrid"><div><span>Orders</span><b>{orders.length}</b></div><div><span>Recorded order value</span><b>{money(orders.filter(o=>o.status!=='cancelled').reduce((s,o)=>s+Number(o.total),0))}</b></div><div><span>This month</span><b>{money(orders.filter(o=>new Date(o.created_at).getMonth()===new Date().getMonth()&&new Date(o.created_at).getFullYear()===new Date().getFullYear()&&o.status!=='cancelled').reduce((s,o)=>s+Number(o.total),0))}</b></div></div><h3>Monthly order value</h3>{Object.entries(monthly).map(([m,v])=><div className="monthlyRow" key={m}><span>{m}</span><b>{money(v)}</b></div>)}<h3>Recent orders</h3><div className="orderList">{orders.map(o=><div className="adminOrder" key={o.id}><b>{o.customer_name} · {money(o.total)}</b><span>{new Date(o.created_at).toLocaleString('en-IN')} · {o.phone}</span><span>{o.address}</span><select value={o.status} onChange={e=>updateOrder(o.id,e.target.value)}>{['pending','confirmed','packed','shipped','completed','cancelled'].map(s=><option key={s}>{s}</option>)}</select></div>)}{!orders.length&&<p className="muted">No orders recorded yet.</p>}</div></>:<><form className="productForm" onSubmit={saveProduct}><label>Product name<input required value={productForm.name} onChange={e=>setProductForm({...productForm,name:e.target.value})}/></label><label>Category<select value={productForm.category} onChange={e=>setProductForm({...productForm,category:e.target.value})}>{['Ethnic Wear','Festive','Suit Sets','Accessories'].map(s=><option key={s}>{s}</option>)}</select></label><label>Price (₹)<input type="number" min="0" required value={productForm.price} onChange={e=>setProductForm({...productForm,price:e.target.value})}/></label><label>Stock quantity<input type="number" min="0" required value={productForm.stock} onChange={e=>setProductForm({...productForm,stock:e.target.value})}/></label><label>Product image URL<input type="url" required value={productForm.image_url} onChange={e=>setProductForm({...productForm,image_url:e.target.value})} placeholder="https://…"/></label><label>Description<textarea value={productForm.description} onChange={e=>setProductForm({...productForm,description:e.target.value})}/></label><button className="button" disabled={busy}>SAVE PRODUCT</button></form><h3>Current products</h3>{products.map(p=><div className="monthlyRow" key={p.id}><span>{p.name} · {money(p.price)}</span>{!String(p.id).startsWith('sample-')&&<button className="deleteBtn" onClick={()=>deleteProduct(p.id)}><Trash2 size={14}/> Delete</button>}</div>)}</>}</>}<div className="adminFooter"><span>Signed in as {session?.user?.email}</span><button onClick={signOut}><LogOut size={14}/> Sign out</button></div></section></div>}
  </>;
}
createRoot(document.getElementById('root')).render(<App/>);
